package com.luxoft.cars;

public enum GearBox {

	MANUAL, AUTOMATIC, BOTH
}
